
package com.TODO;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

// Custom cell renderer for luxury look
public class TaskCellRenderer extends DefaultListCellRenderer {

    // 🟢 Define custom Rolex-themed colors
    private static final Color ROLEX_GREEN = new Color(0, 92, 75);
    private static final Color ROLEX_LIGHT_GREEN = new Color(86, 125, 70);
    private static final Color ROLEX_DARK_GREEN = new Color(0, 61, 50);
    private static final Color ROLEX_GOLD = new Color(212, 175, 55);
    private static final Color CREAM_WHITE = new Color(245, 245, 240);
    private static final Color DARK_TEXT = new Color(30, 30, 30);

    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        // If value is null (empty list or loading), return default
        if (value == null || !(value instanceof Task)) {
            return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        }

        Task task = (Task) value;

        JPanel panel = new JPanel(new BorderLayout(10, 5));
        panel.setBorder(new CompoundBorder(
                new MatteBorder(0, 0, 1, 0, ROLEX_GREEN.brighter()),
                new EmptyBorder(10, 15, 10, 15)
        ));

        panel.setBackground(isSelected ? ROLEX_LIGHT_GREEN : Color.WHITE);

        // Title
        JLabel titleLabel = new JLabel(task.getTitle());
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        titleLabel.setForeground(isSelected ? Color.WHITE : DARK_TEXT);

        if (task.isCompleted()) {
            titleLabel.setText("✓ " + task.getTitle());
            titleLabel.setForeground(isSelected ? Color.WHITE : Color.GRAY);
        }

        // Description
        JLabel descLabel = new JLabel(task.getDescription().isEmpty() ? "No description" : task.getDescription());
        descLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        descLabel.setForeground(isSelected ? CREAM_WHITE : Color.GRAY);

        // Priority and category info
        JLabel infoLabel = new JLabel(String.format("Priority: %d | Category: %s",
                task.getPriority(), task.getCategory()));
        infoLabel.setFont(new Font("SansSerif", Font.ITALIC, 11));
        infoLabel.setForeground(isSelected ? ROLEX_GOLD : ROLEX_DARK_GREEN);

        JPanel textPanel = new JPanel(new GridLayout(3, 1));
        textPanel.setOpaque(false);
        textPanel.add(titleLabel);
        textPanel.add(descLabel);
        textPanel.add(infoLabel);

        panel.add(textPanel, BorderLayout.CENTER);

        return panel;
    }
}
