package com.TODO;

import java.io.*;
import java.util.ArrayList;

/**
 * FileHandler - Manages saving and loading tasks from disk.
 * Uses Java Serialization to persist the ArrayList<Task> object.
 */
public class FileHandler {
    private static final String FILE_NAME = "tasks.dat";

    // Save tasks to file
    public static void saveTasks(ArrayList<Task> tasks) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(tasks);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error saving tasks: " + e.getMessage());
        }
    }

    // Load tasks from file
    @SuppressWarnings("unchecked")
    public static ArrayList<Task> loadTasks() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return new ArrayList<>(); // return empty list if no file found
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (ArrayList<Task>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println("Error loading tasks: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
