package com.TODO;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class TaskManager {
    private ArrayList<Task> tasks;
    private ArrayList<Category> categories;

    public TaskManager() {
        // 🟢 Load tasks from file
        tasks = FileHandler.loadTasks();

        categories = new ArrayList<>();
        initializeDefaultCategories();
    }

    private void initializeDefaultCategories() {
        categories.add(new Category("Work", new Color(0, 92, 59)));
        categories.add(new Category("Personal", new Color(0, 73, 47)));
        categories.add(new Category("Shopping", new Color(1, 112, 72)));
        categories.add(new Category("Health", new Color(46, 125, 50)));
    }

    // CREATE
    public void addTask(Task task) {
        tasks.add(task);
        FileHandler.saveTasks(tasks);
    }

    // READ
    public ArrayList<Task> getAllTasks() {
        return new ArrayList<>(tasks);
    }

    public ArrayList<Task> getTasksByCategory(String category) {
        ArrayList<Task> filtered = new ArrayList<>();
        for (Task task : tasks) {
            if (task.getCategory().equals(category)) {
                filtered.add(task);
            }
        }
        return filtered;
    }

    // UPDATE
    public void updateTask(int index, Task updatedTask) {
        if (index >= 0 && index < tasks.size()) {
            tasks.set(index, updatedTask);
            FileHandler.saveTasks(tasks);
        }
    }

    // DELETE
    public void deleteTask(int index) {
        if (index >= 0 && index < tasks.size()) {
            tasks.remove(index);
            FileHandler.saveTasks(tasks);
        }
    }

    // PRIORITIZE
    public void sortByPriority() {
        Collections.sort(tasks, new Comparator<Task>() {
            @Override
            public int compare(Task t1, Task t2) {
                return Integer.compare(t2.getPriority(), t1.getPriority());
            }
        });
        FileHandler.saveTasks(tasks);
    }

    // Category Management
    public void addCategory(Category category) {
        categories.add(category);
    }

    public ArrayList<Category> getCategories() {
        return new ArrayList<>(categories);
    }
}
