package com.TODO;
import java.io.Serializable;

/**
 * Task Class - Represents individual TODO items
 * Implements Serializable for file persistence
 */
public class Task implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String title;
    private String description;
    private String category;
    private int priority; // 1-5 (5 being highest)
    private boolean isCompleted;
    
    public Task(String title, String description, String category, int priority) {
        this.title = title;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.isCompleted = false;
    }
    
    // Getters
    public String getTitle() { 
        return title; 
    }
    
    public String getDescription() { 
        return description; 
    }
    
    public String getCategory() { 
        return category; 
    }
    
    public int getPriority() { 
        return priority; 
    }
    
    public boolean isCompleted() { 
        return isCompleted; 
    }
    
    // Setters
    public void setTitle(String title) { 
        this.title = title; 
    }
    
    public void setDescription(String description) { 
        this.description = description; 
    }
    
    public void setCategory(String category) { 
        this.category = category; 
    }
    
    public void setPriority(int priority) { 
        this.priority = priority; 
    }
    
    public void setCompleted(boolean completed) { 
        this.isCompleted = completed; 
    }
    
    @Override
    public String toString() {
        return String.format("[%s] %s - %s (Priority: %d)", 
            isCompleted ? "✓" : " ", title, category, priority);
    }
}