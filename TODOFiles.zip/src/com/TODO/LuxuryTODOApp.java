package com.TODO;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class LuxuryTODOApp extends JFrame {
    // Rolex-inspired color palette
    private static final Color ROLEX_GREEN = new Color(0, 92, 59);
    private static final Color ROLEX_DARK_GREEN = new Color(0, 73, 47);
    private static final Color ROLEX_LIGHT_GREEN = new Color(1, 112, 72);
    private static final Color ROLEX_GOLD = new Color(169, 134, 78);
    private static final Color CREAM_WHITE = new Color(250, 248, 245);
    private static final Color DARK_TEXT = new Color(33, 33, 33);
    
    private TaskManager taskManager;
    private DefaultListModel<Task> taskListModel;
    private JList<Task> taskList;
    private JComboBox<String> categoryFilter;
    
    public LuxuryTODOApp() {
        taskManager = new TaskManager();
        taskListModel = new DefaultListModel<>();
        
        setTitle("Luxury TODO Manager");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initializeUI();
        setVisible(true);
    }
    
    private void initializeUI() {
        setLayout(new BorderLayout(0, 0));
        getContentPane().setBackground(CREAM_WHITE);
        
        // Header Panel
        add(createHeaderPanel(), BorderLayout.NORTH);
        
        // Main Content Panel
        add(createMainPanel(), BorderLayout.CENTER);
        
        // Control Panel
        add(createControlPanel(), BorderLayout.SOUTH);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(ROLEX_GREEN);
        headerPanel.setBorder(new EmptyBorder(25, 40, 25, 40));
        
        JLabel titleLabel = new JLabel("LUXURY TODO MANAGER");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 32));
        titleLabel.setForeground(ROLEX_GOLD);
        
        JLabel subtitleLabel = new JLabel("Organize Your Excellence");
        subtitleLabel.setFont(new Font("SansSerif", Font.ITALIC, 14));
        subtitleLabel.setForeground(CREAM_WHITE);
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 5));
        titlePanel.setBackground(ROLEX_GREEN);
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);
        
        headerPanel.add(titlePanel, BorderLayout.WEST);
        
        return headerPanel;
    }
    
    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setBackground(CREAM_WHITE);
        mainPanel.setBorder(new EmptyBorder(30, 40, 30, 40));
        
        // Task List with custom renderer
        taskList = new JList<>(taskListModel);
        taskList.setCellRenderer(new TaskCellRenderer());
        taskList.setFont(new Font("SansSerif", Font.PLAIN, 14));
        taskList.setBackground(Color.WHITE);
        taskList.setSelectionBackground(ROLEX_LIGHT_GREEN);
        taskList.setSelectionForeground(Color.WHITE);
        taskList.setFixedCellHeight(70);
        
        JScrollPane scrollPane = new JScrollPane(taskList);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ROLEX_GREEN, 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Filter Panel
        JPanel filterPanel = createFilterPanel();
        
        mainPanel.add(filterPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        return mainPanel;
    }
    
    private JPanel createFilterPanel() {
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        filterPanel.setBackground(CREAM_WHITE);
        
        JLabel filterLabel = new JLabel("Filter by Category:");
        filterLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        filterLabel.setForeground(DARK_TEXT);
        
        String[] categories = {"All", "Work", "Personal", "Shopping", "Health"};
        categoryFilter = new JComboBox<>(categories);
        categoryFilter.setFont(new Font("SansSerif", Font.PLAIN, 13));
        categoryFilter.setBackground(Color.WHITE);
        categoryFilter.setPreferredSize(new Dimension(150, 30));
        categoryFilter.addActionListener(e -> filterTasks());
        
        JButton sortButton = createStyledButton("Sort by Priority", ROLEX_LIGHT_GREEN);
        sortButton.addActionListener(e -> sortTasks());
        
        filterPanel.add(filterLabel);
        filterPanel.add(categoryFilter);
        filterPanel.add(Box.createHorizontalStrut(20));
        filterPanel.add(sortButton);
        
        return filterPanel;
    }
    
    private JPanel createControlPanel() {
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        controlPanel.setBackground(ROLEX_DARK_GREEN);
        controlPanel.setBorder(new EmptyBorder(15, 40, 15, 40));
        
        JButton addButton = createStyledButton("Add Task", ROLEX_GOLD);
        JButton editButton = createStyledButton("Edit Task", ROLEX_LIGHT_GREEN);
        JButton deleteButton = createStyledButton("Delete Task", new Color(198, 40, 40));
        JButton completeButton = createStyledButton("Toggle Complete", new Color(76, 175, 80));
        
        addButton.addActionListener(e -> showAddTaskDialog());
        editButton.addActionListener(e -> showEditTaskDialog());
        deleteButton.addActionListener(e -> deleteSelectedTask());
        completeButton.addActionListener(e -> toggleTaskCompletion());
        
        controlPanel.add(addButton);
        controlPanel.add(editButton);
        controlPanel.add(deleteButton);
        controlPanel.add(completeButton);
        
        return controlPanel;
    }
    
    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.brighter());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }
    
    private void showAddTaskDialog() {
        JDialog dialog = new JDialog(this, "Add New Task", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 15));
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(CREAM_WHITE);
        
        JLabel titleLabel = new JLabel("Title:");
        JTextField titleField = new JTextField();
        
        JLabel descLabel = new JLabel("Description:");
        JTextArea descArea = new JTextArea(3, 20);
        JScrollPane descScroll = new JScrollPane(descArea);
        
        JLabel categoryLabel = new JLabel("Category:");
        String[] categories = {"Work", "Personal", "Shopping", "Health"};
        JComboBox<String> categoryBox = new JComboBox<>(categories);
        
        JLabel priorityLabel = new JLabel("Priority (1-5):");
        JSpinner prioritySpinner = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1));
        
        formPanel.add(titleLabel);
        formPanel.add(titleField);
        formPanel.add(descLabel);
        formPanel.add(descScroll);
        formPanel.add(categoryLabel);
        formPanel.add(categoryBox);
        formPanel.add(priorityLabel);
        formPanel.add(prioritySpinner);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(CREAM_WHITE);
        
        JButton saveButton = createStyledButton("Save", ROLEX_GREEN);
        JButton cancelButton = createStyledButton("Cancel", Color.GRAY);
        
        saveButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String desc = descArea.getText().trim();
            String category = (String) categoryBox.getSelectedItem();
            int priority = (Integer) prioritySpinner.getValue();
            
            if (!title.isEmpty()) {
                Task task = new Task(title, desc, category, priority);
                taskManager.addTask(task);
                refreshTaskList();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Title is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelButton.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private void showEditTaskDialog() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a task to edit!", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Task task = taskListModel.getElementAt(selectedIndex);
        
        JDialog dialog = new JDialog(this, "Edit Task", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 15));
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(CREAM_WHITE);
        
        JLabel titleLabel = new JLabel("Title:");
        JTextField titleField = new JTextField(task.getTitle());
        
        JLabel descLabel = new JLabel("Description:");
        JTextArea descArea = new JTextArea(task.getDescription(), 3, 20);
        JScrollPane descScroll = new JScrollPane(descArea);
        
        JLabel categoryLabel = new JLabel("Category:");
        String[] categories = {"Work", "Personal", "Shopping", "Health"};
        JComboBox<String> categoryBox = new JComboBox<>(categories);
        categoryBox.setSelectedItem(task.getCategory());
        
        JLabel priorityLabel = new JLabel("Priority (1-5):");
        JSpinner prioritySpinner = new JSpinner(new SpinnerNumberModel(task.getPriority(), 1, 5, 1));
        
        formPanel.add(titleLabel);
        formPanel.add(titleField);
        formPanel.add(descLabel);
        formPanel.add(descScroll);
        formPanel.add(categoryLabel);
        formPanel.add(categoryBox);
        formPanel.add(priorityLabel);
        formPanel.add(prioritySpinner);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(CREAM_WHITE);
        
        JButton saveButton = createStyledButton("Save", ROLEX_GREEN);
        JButton cancelButton = createStyledButton("Cancel", Color.GRAY);
        
        saveButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String desc = descArea.getText().trim();
            String category = (String) categoryBox.getSelectedItem();
            int priority = (Integer) prioritySpinner.getValue();
            
            if (!title.isEmpty()) {
                task.setTitle(title);
                task.setDescription(desc);
                task.setCategory(category);
                task.setPriority(priority);
                refreshTaskList();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Title is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelButton.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    
    private void deleteSelectedTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to delete this task?", 
                "Confirm Delete", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                taskManager.deleteTask(getActualTaskIndex(selectedIndex));
                refreshTaskList();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a task to delete!", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void toggleTaskCompletion() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Task task = taskListModel.getElementAt(selectedIndex);
            task.setCompleted(!task.isCompleted());
            refreshTaskList();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a task!", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void filterTasks() {
        refreshTaskList();
    }
    
    private void sortTasks() {
        taskManager.sortByPriority();
        refreshTaskList();
    }
    
    private void refreshTaskList() {
        taskListModel.clear();
        String selectedCategory = (String) categoryFilter.getSelectedItem();
        
        ArrayList<Task> tasks;
        if ("All".equals(selectedCategory)) {
            tasks = taskManager.getAllTasks();
        } else {
            tasks = taskManager.getTasksByCategory(selectedCategory);
        }
        
        for (Task task : tasks) {
            taskListModel.addElement(task);
        }
    }
    
    private int getActualTaskIndex(int displayIndex) {
        Task task = taskListModel.getElementAt(displayIndex);
        return taskManager.getAllTasks().indexOf(task);
    }
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new LuxuryTODOApp());
    }
}